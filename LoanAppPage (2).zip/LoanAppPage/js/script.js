
// for Captacha 
function Captcha(){
  var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
  'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z', 
      '0','1','2','3','4','5','6','7','8','9');
  var i;
  for (i=0;i<6;i++){
    //Math. random() function returns a floating-point 
    // in the range 0 to less than 1
    //Math.floor() rounds a number DOWN to the nearest integer:
      var a = alpha[Math.floor(Math.random() * alpha.length)];
      var b = alpha[Math.floor(Math.random() * alpha.length)];
      var c = alpha[Math.floor(Math.random() * alpha.length)];
      var d = alpha[Math.floor(Math.random() * alpha.length)];
      var e = alpha[Math.floor(Math.random() * alpha.length)];
      var f = alpha[Math.floor(Math.random() * alpha.length)];
      var g = alpha[Math.floor(Math.random() * alpha.length)];
    }
      var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
      //innerHTML property is part of the Document Object Model
      document.getElementById("mainCaptcha").innerHTML = code
  document.getElementById("mainCaptcha").value = code
}
   //to validate the captcha
function ValidateCaptcha(){
  var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
  var string2 = removeSpaces(document.getElementById('txtInput').value);
  if (string1 == string2){
      return true;
  }
  else{        
       return false;
  }
}
//function for remove spaces
function removeSpaces(string){
  return string.split(' ').join('');
}


//Name Validation
function lettersAndSpaceCheck(name){
  var regEx = /^[a-z][a-z\s]*$/;
  if(name.value.match(regEx)){
     return true;
    }
  else
    {
    alert("Please enter letters and space only");
    return false;
    }
}


//  for Email Validation
 function validateEmail(inputText){
 var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(inputText.value.match(mailformat)){
alert("Valid email address!");
document.form1.text1.focus();
return true;
}
else{
alert("You have entered an invalid email address!");
document.form1.text1.focus();
return false;
}
}

//  for Pan Card validation
function pan_validate(pan) {
var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
if (regpan.test(pan) == false) {
  document.getElementById("status").innerHTML ="PAN Number Not Valid";
} 
else {
  // alert("Pan No Valid");
  document.getElementById("status").innerHTML = "You Entered a Valid Acc No";

}
}

const form  = document.getElementById('action.html');
const NAME_REQUIRED = "Please enter your name";
const EMAIL_REQUIRED = "Please enter your email";
const EMAIL_INVALID = "Please enter a correct email address format";




const name = form.elements['name'];
const email = form.elements['email'];
const pan = form.elements['pan'];
const loan_amount = form.elements['loan_amount'];
// getting the element's value
let fullName = name.value;
let emailAddress = email.value;

form.addEventListener('submit', (event) => {
    // handle the form data

     // stop form submission
     event.preventDefault();

     // validate the form
	let nameValid = hasValue(form.elements["name"], NAME_REQUIRED);
	let emailValid = validateEmail(form.elements["email"], EMAIL_REQUIRED, EMAIL_INVALID);
	// if valid, submit the form.
	if (nameValid && emailValid) {
		alert("Demo only. No form was posted.");
	}
});


// show a message with a type of the input
function showMessage(input, message, type) {
	// get the small element and set the message
	const msg = input.parentNode.querySelector("small");
	msg.innerText = message;
	// update the class for the input
	input.className = type ? "success" : "error";
	return type;
}

function showError(input, message) {
	return showMessage(input, message, false);
}

function showSuccess(input) {
	return showMessage(input, "", true);
}

function hasValue(input, message) {
	if (input.value.trim() === "") {
		return showError(input, message);
	}
	return showSuccess(input);
}

// show a message with a type of the input
function showMessage(input, message, type) {
	// get the <small> element and set the message
	const msg = input.parentNode.querySelector("small");
	msg.innerText = message;
	// update the class for the input
	input.className = type ? "success" : "error";
	return type;
}








// function form data
// function getData(){
//   //gettting the values
//   var email = document.getElementById("email").value;
//   var name= document.getElementById("name").value; 
//   var pan= document.getElementById("pan").value; 
//   var loan_money= document.getElementById("loan_amount").value; 
//   //saving the values in local storage
//   localStorage.setItem("txtValue", email);
//   localStorage.setItem("txtValue1", name);
//   localStorage.setItem("txtValue2", pan);
//   localStorage.setItem("txtValue3", loan_money);   
//   document.write("form sucessfully ");
// }
// function myfunc(){
//   var x = document.getElementById("mySubmit").formTarget;
// }



// for Loan Amount Validation
var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

function inWords (num) {
  if ((num = num.toString()).length > 9) return 'overflow';
  n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!n) return; var str = '';
  str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
  str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
  str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
  str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
  str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
  return str;
}

document.getElementById('number').onkeyup = function () {
  document.getElementById('words').innerHTML = inWords(document.getElementById('number').value);
};
